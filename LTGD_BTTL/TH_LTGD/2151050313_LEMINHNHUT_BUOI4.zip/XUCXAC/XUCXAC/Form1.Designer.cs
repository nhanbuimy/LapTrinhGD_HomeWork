﻿namespace XUCXAC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gr1 = new System.Windows.Forms.GroupBox();
            this.picChoose = new System.Windows.Forms.PictureBox();
            this.bt6 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.picResult = new System.Windows.Forms.PictureBox();
            this.btReset = new System.Windows.Forms.Button();
            this.btPlay = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbLose = new System.Windows.Forms.Label();
            this.lbWin = new System.Windows.Forms.Label();
            this.lbCount = new System.Windows.Forms.Label();
            this.listResult = new System.Windows.Forms.ListBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.gr1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picChoose)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // gr1
            // 
            this.gr1.Controls.Add(this.picChoose);
            this.gr1.Controls.Add(this.bt6);
            this.gr1.Controls.Add(this.bt3);
            this.gr1.Controls.Add(this.bt5);
            this.gr1.Controls.Add(this.bt4);
            this.gr1.Controls.Add(this.bt2);
            this.gr1.Controls.Add(this.bt1);
            this.gr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gr1.Location = new System.Drawing.Point(36, 11);
            this.gr1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.gr1.Name = "gr1";
            this.gr1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.gr1.Size = new System.Drawing.Size(578, 272);
            this.gr1.TabIndex = 0;
            this.gr1.TabStop = false;
            this.gr1.Text = "Hãy chọn 1 số";
            this.toolTip1.SetToolTip(this.gr1, "Click một nút để đoán số");
            this.gr1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // picChoose
            // 
            this.picChoose.Location = new System.Drawing.Point(217, 59);
            this.picChoose.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.picChoose.Name = "picChoose";
            this.picChoose.Size = new System.Drawing.Size(150, 144);
            this.picChoose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picChoose.TabIndex = 1;
            this.picChoose.TabStop = false;
            // 
            // bt6
            // 
            this.bt6.Location = new System.Drawing.Point(460, 177);
            this.bt6.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(66, 60);
            this.bt6.TabIndex = 0;
            this.bt6.Text = "6";
            this.toolTip1.SetToolTip(this.bt6, "Click một nút để đoán số");
            this.bt6.UseVisualStyleBackColor = true;
            this.bt6.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt3
            // 
            this.bt3.Location = new System.Drawing.Point(52, 177);
            this.bt3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(66, 60);
            this.bt3.TabIndex = 0;
            this.bt3.Text = "3";
            this.toolTip1.SetToolTip(this.bt3, "Click một nút để đoán số");
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt5
            // 
            this.bt5.Location = new System.Drawing.Point(460, 108);
            this.bt5.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(66, 60);
            this.bt5.TabIndex = 0;
            this.bt5.Text = "5";
            this.toolTip1.SetToolTip(this.bt5, "Click một nút để đoán số");
            this.bt5.UseVisualStyleBackColor = true;
            this.bt5.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt4
            // 
            this.bt4.Location = new System.Drawing.Point(460, 39);
            this.bt4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(66, 60);
            this.bt4.TabIndex = 0;
            this.bt4.Text = "4";
            this.toolTip1.SetToolTip(this.bt4, "Click một nút để đoán số");
            this.bt4.UseVisualStyleBackColor = true;
            this.bt4.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt2
            // 
            this.bt2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(2)))));
            this.bt2.Cursor = System.Windows.Forms.Cursors.PanNorth;
            this.bt2.Location = new System.Drawing.Point(52, 108);
            this.bt2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(66, 60);
            this.bt2.TabIndex = 0;
            this.bt2.Text = "2";
            this.toolTip1.SetToolTip(this.bt2, "Click một nút để đoán số");
            this.bt2.UseVisualStyleBackColor = false;
            this.bt2.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt1
            // 
            this.bt1.Location = new System.Drawing.Point(52, 39);
            this.bt1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(66, 60);
            this.bt1.TabIndex = 0;
            this.bt1.Text = "1";
            this.toolTip1.SetToolTip(this.bt1, "Click một nút để đoán số");
            this.bt1.UseVisualStyleBackColor = true;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.picResult);
            this.groupBox1.Controls.Add(this.btReset);
            this.groupBox1.Controls.Add(this.btPlay);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(36, 292);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.groupBox1.Size = new System.Drawing.Size(578, 262);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quay số (sinh số ngẫu nhiên)";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // picResult
            // 
            this.picResult.Location = new System.Drawing.Point(222, 39);
            this.picResult.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.picResult.Name = "picResult";
            this.picResult.Size = new System.Drawing.Size(144, 136);
            this.picResult.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picResult.TabIndex = 1;
            this.picResult.TabStop = false;
            // 
            // btReset
            // 
            this.btReset.Location = new System.Drawing.Point(362, 198);
            this.btReset.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btReset.Name = "btReset";
            this.btReset.Size = new System.Drawing.Size(216, 64);
            this.btReset.TabIndex = 0;
            this.btReset.Text = "Reset (ESC)";
            this.btReset.UseVisualStyleBackColor = true;
            this.btReset.Click += new System.EventHandler(this.btReset_Click);
            // 
            // btPlay
            // 
            this.btPlay.Location = new System.Drawing.Point(0, 202);
            this.btPlay.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btPlay.Name = "btPlay";
            this.btPlay.Size = new System.Drawing.Size(249, 59);
            this.btPlay.TabIndex = 0;
            this.btPlay.Text = "Quay số (Enter)";
            this.btPlay.UseVisualStyleBackColor = true;
            this.btPlay.Click += new System.EventHandler(this.btPlay_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbLose);
            this.groupBox2.Controls.Add(this.lbWin);
            this.groupBox2.Controls.Add(this.lbCount);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(36, 573);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.groupBox2.Size = new System.Drawing.Size(578, 246);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thống kê";
            // 
            // lbLose
            // 
            this.lbLose.AutoSize = true;
            this.lbLose.Location = new System.Drawing.Point(19, 185);
            this.lbLose.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbLose.Name = "lbLose";
            this.lbLose.Size = new System.Drawing.Size(118, 42);
            this.lbLose.TabIndex = 0;
            this.lbLose.Text = "label1";
            // 
            // lbWin
            // 
            this.lbWin.AutoSize = true;
            this.lbWin.Location = new System.Drawing.Point(19, 119);
            this.lbWin.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbWin.Name = "lbWin";
            this.lbWin.Size = new System.Drawing.Size(118, 42);
            this.lbWin.TabIndex = 0;
            this.lbWin.Text = "label1";
            // 
            // lbCount
            // 
            this.lbCount.AutoSize = true;
            this.lbCount.Location = new System.Drawing.Point(19, 55);
            this.lbCount.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbCount.Name = "lbCount";
            this.lbCount.Size = new System.Drawing.Size(118, 42);
            this.lbCount.TabIndex = 0;
            this.lbCount.Text = "label1";
            // 
            // listResult
            // 
            this.listResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listResult.FormattingEnabled = true;
            this.listResult.ItemHeight = 37;
            this.listResult.Location = new System.Drawing.Point(624, 38);
            this.listResult.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.listResult.Name = "listResult";
            this.listResult.Size = new System.Drawing.Size(399, 781);
            this.listResult.TabIndex = 2;
            this.listResult.SelectedIndexChanged += new System.EventHandler(this.listResult_SelectedIndexChanged);
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Đoán số";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 865);
            this.Controls.Add(this.listResult);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gr1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "2151050313 - Le Minh Nhut";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gr1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picChoose)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gr1;
        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.PictureBox picChoose;
        private System.Windows.Forms.Button bt6;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bt5;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox picResult;
        private System.Windows.Forms.Button btReset;
        private System.Windows.Forms.Button btPlay;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbLose;
        private System.Windows.Forms.Label lbWin;
        private System.Windows.Forms.Label lbCount;
        private System.Windows.Forms.ListBox listResult;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

