﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XUCXAC
{
    public partial class Form1 : Form
    {
        string partImg; //Duong dan den thu muc hinhxucxac
        int nchoose; //so nguoi dung doan
        int nCount; //So lan quay
        int nWin; //so lan doan dung
        int nLose; //So lan doan sai
        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Init() {
            partImg = Application.StartupPath + @"\hinhxucxac\";
            nchoose = 1;
            nCount = nWin = nLose = 0;
            picChoose.Image = Image.FromFile(partImg + "1.jpg");
            picResult.Image = null;
            lbCount.Text = lbWin.Text = lbLose.Text = "";
            listResult.Items.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Init();
        }

        private void bt1_Click(object sender, EventArgs e)
        {
            Button bt = (Button)sender;
            nchoose = int.Parse(bt.Text);
            picChoose.Image = Image.FromFile(partImg + nchoose.ToString()+".jpg");
        }

        private void Play()
        {
            int n = rand.Next(1, 7);
            picResult.Image = Image.FromFile(partImg + n.ToString() + ".jpg");
            nCount++;
            string kq = "Thua";

            if (n == nchoose)
            {
                nWin++;
                kq = "Thắng";
            }
            else
            {
                nLose++;
                kq = "Thua";
            }
            //cap nhat thong ke
            lbCount.Text = String.Format("Lần đoán: {0}", nCount);
            lbWin.Text = String.Format("Lần thắng: {0} ({1:0.00})", nWin, (double)nWin * 100 / nCount);
            lbLose.Text = String.Format("Lần thua: {0} ({1:0.00})", nLose, (double)nLose * 100 / nCount);
            listResult.Items.Add(String.Format("{0}. {1} (Đoán {2} ra {3})",nCount, kq, nchoose, n));
        }
        private void btPlay_Click(object sender, EventArgs e)
        {
            Play();
        }
        protected override bool ProcessDialogKey(Keys keyData)
        {
            switch(keyData)
            {
                case Keys.Enter:Play(); break;
                    case Keys.Escape:Init(); break;
            }    
            return false;
        }

        private void listResult_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btReset_Click(object sender, EventArgs e)
        {
            listResult.Items.Clear();
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
    }
}
