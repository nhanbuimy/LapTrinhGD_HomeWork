﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quayso
{
    public partial class Form1 : Form
    {
        string partImg;
        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbName.Text = "          2151050313 - LÊ MINH NHỰT          ";
            partImg = Application.StartupPath + @"\hinhxucxac\";
            pic1.Image = pic2.Image = pic3.Image = Image.FromFile(partImg + "6.jpg");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbName.Text = lbName.Text.Substring(1) + lbName.Text.Substring(0, 1);

        }

        private void btQuayso_Click(object sender, EventArgs e)
        {
            int so1 = rand.Next(1, 7);
            int so2 = rand.Next(1, 7);
            int so3 = rand.Next(1, 7);
            pic1.Image = Image.FromFile(partImg + so1.ToString() + ".jpg");
            pic2.Image = Image.FromFile(partImg + so2.ToString() + ".jpg");
            pic3.Image = Image.FromFile(partImg + so3.ToString() + ".jpg");
            lbResult.Text = String.Format("{0}", so1 + so2 + so3);
        }

        private void btDong_Click(object sender, EventArgs e)
        {
            Close();    
        }
    }
}
