﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Cacpheptinh
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btCong_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtSo1.Text);
            int b = int.Parse(txtSo2.Text);
            lbKetqua.Text = String.Format("{0}", a + b);
        }

        private void btTru_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtSo1.Text);
            int b = int.Parse(txtSo2.Text);
            lbKetqua.Text = String.Format("{0}", a - b);
        }

        private void btNhan_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtSo1.Text);
            int b = int.Parse(txtSo2.Text);
            lbKetqua.Text = String.Format("{0}", a * b);
        }

        private void btChia_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtSo1.Text);
                int b = int.Parse(txtSo2.Text);
                if (b == 0)
                    throw new DivideByZeroException();
                    lbKetqua.Text = String.Format("{0:0.##}", (double)a / b);
            }
            catch (DivideByZeroException)
            {
                lbKetqua.Text = " Số chia phải khác 0 ";
            }
        }

        private void btDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
