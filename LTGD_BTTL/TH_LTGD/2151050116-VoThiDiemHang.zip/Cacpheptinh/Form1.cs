﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cacpheptinh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btTinh_Click(object sender, EventArgs e)
        {
            try
            {
                int a = checked(int.Parse(txtSo1.Text));
                int b = checked(int.Parse(txtSo2.Text));
                if (rdCong.Checked)
                    lbKetqua.Text = String.Format("{0}", checked(a + b));
                else if (rdTru.Checked)
                    lbKetqua.Text = String.Format("{0}", checked(a - b));
                else if (rdNhan.Checked)
                    lbKetqua.Text = String.Format("{0}", checked(a * b));
                else if (rdChiadu.Checked)
                    lbKetqua.Text = String.Format("{0}", a % b);
                else
                {
                    if (b == 0)
                        throw new DivideByZeroException();
                    lbKetqua.Text = String.Format("{0:0.##}", (double)a / b);
                }
            }
            catch (DivideByZeroException)
            {
                lbKetqua.Text = "Không thể chia cho 0 ";
            }
            catch (FormatException)
            {
                lbKetqua.Text = " Bạn phải nhập hai số ";
            }
            catch (OverflowException)
            {
                lbKetqua.Text = " Số quá lớn hoặc quá nhỏ";
            }
    }

        private void btDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
