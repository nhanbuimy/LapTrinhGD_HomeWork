﻿namespace LTGD_GK2022_2023
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlBieuDo = new System.Windows.Forms.Panel();
            this.pnlChuThich = new System.Windows.Forms.Panel();
            this.lbMau5 = new System.Windows.Forms.Label();
            this.lbMau4 = new System.Windows.Forms.Label();
            this.lbMau3 = new System.Windows.Forms.Label();
            this.lbMau2 = new System.Windows.Forms.Label();
            this.lbMau1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlChuThich.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBieuDo
            // 
            this.pnlBieuDo.BackColor = System.Drawing.Color.Silver;
            this.pnlBieuDo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBieuDo.Location = new System.Drawing.Point(12, 12);
            this.pnlBieuDo.Name = "pnlBieuDo";
            this.pnlBieuDo.Size = new System.Drawing.Size(925, 739);
            this.pnlBieuDo.TabIndex = 0;
            this.pnlBieuDo.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1_Paint);
            // 
            // pnlChuThich
            // 
            this.pnlChuThich.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlChuThich.Controls.Add(this.lbMau5);
            this.pnlChuThich.Controls.Add(this.lbMau4);
            this.pnlChuThich.Controls.Add(this.lbMau3);
            this.pnlChuThich.Controls.Add(this.lbMau2);
            this.pnlChuThich.Controls.Add(this.lbMau1);
            this.pnlChuThich.Controls.Add(this.label5);
            this.pnlChuThich.Controls.Add(this.label4);
            this.pnlChuThich.Controls.Add(this.label3);
            this.pnlChuThich.Controls.Add(this.label2);
            this.pnlChuThich.Controls.Add(this.label1);
            this.pnlChuThich.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlChuThich.Location = new System.Drawing.Point(944, 12);
            this.pnlChuThich.Name = "pnlChuThich";
            this.pnlChuThich.Size = new System.Drawing.Size(463, 739);
            this.pnlChuThich.TabIndex = 1;
            // 
            // lbMau5
            // 
            this.lbMau5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbMau5.Location = new System.Drawing.Point(96, 487);
            this.lbMau5.Name = "lbMau5";
            this.lbMau5.Size = new System.Drawing.Size(50, 50);
            this.lbMau5.TabIndex = 1;
            this.lbMau5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMau4
            // 
            this.lbMau4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbMau4.Location = new System.Drawing.Point(96, 415);
            this.lbMau4.Name = "lbMau4";
            this.lbMau4.Size = new System.Drawing.Size(50, 50);
            this.lbMau4.TabIndex = 1;
            this.lbMau4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMau3
            // 
            this.lbMau3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbMau3.Location = new System.Drawing.Point(96, 343);
            this.lbMau3.Name = "lbMau3";
            this.lbMau3.Size = new System.Drawing.Size(50, 50);
            this.lbMau3.TabIndex = 1;
            this.lbMau3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMau2
            // 
            this.lbMau2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbMau2.Location = new System.Drawing.Point(96, 271);
            this.lbMau2.Name = "lbMau2";
            this.lbMau2.Size = new System.Drawing.Size(50, 50);
            this.lbMau2.TabIndex = 1;
            this.lbMau2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMau1
            // 
            this.lbMau1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbMau1.Location = new System.Drawing.Point(96, 199);
            this.lbMau1.Name = "lbMau1";
            this.lbMau1.Size = new System.Drawing.Size(50, 50);
            this.lbMau1.TabIndex = 1;
            this.lbMau1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(152, 500);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "Dịch vụ khác";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(152, 428);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Chạy advertising";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(152, 356);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Bán domain";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(152, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(213, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Outsource thiết kế UI";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(152, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Phát triển phần mềm";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1419, 763);
            this.Controls.Add(this.pnlChuThich);
            this.Controls.Add(this.pnlBieuDo);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.pnlChuThich.ResumeLayout(false);
            this.pnlChuThich.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBieuDo;
        private System.Windows.Forms.Panel pnlChuThich;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbMau5;
        private System.Windows.Forms.Label lbMau4;
        private System.Windows.Forms.Label lbMau3;
        private System.Windows.Forms.Label lbMau2;
        private System.Windows.Forms.Label lbMau1;
    }
}