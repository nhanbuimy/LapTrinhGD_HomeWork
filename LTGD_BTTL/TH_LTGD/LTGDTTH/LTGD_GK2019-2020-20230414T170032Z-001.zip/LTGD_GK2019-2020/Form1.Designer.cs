﻿namespace LTGD_GK2019_2020
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbSo2 = new System.Windows.Forms.Label();
            this.lbTienConLai = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbTienCuoc1 = new System.Windows.Forms.ComboBox();
            this.rdChan = new System.Windows.Forms.RadioButton();
            this.rdLe = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbTienCuoc2 = new System.Windows.Forms.ComboBox();
            this.rd310 = new System.Windows.Forms.RadioButton();
            this.rd1118 = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.lbSo3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbSo1 = new System.Windows.Forms.Label();
            this.chkGiaoDienHinh = new System.Windows.Forms.CheckBox();
            this.btnQuaySo = new System.Windows.Forms.Button();
            this.pctSo1 = new System.Windows.Forms.PictureBox();
            this.pctSo2 = new System.Windows.Forms.PictureBox();
            this.pctSo3 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctSo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSo3)).BeginInit();
            this.SuspendLayout();
            // 
            // lbSo2
            // 
            this.lbSo2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo2.Location = new System.Drawing.Point(508, 33);
            this.lbSo2.Name = "lbSo2";
            this.lbSo2.Size = new System.Drawing.Size(200, 200);
            this.lbSo2.TabIndex = 0;
            this.lbSo2.Text = "label1";
            this.lbSo2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTienConLai
            // 
            this.lbTienConLai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbTienConLai.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbTienConLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTienConLai.Location = new System.Drawing.Point(857, 480);
            this.lbTienConLai.Name = "lbTienConLai";
            this.lbTienConLai.Size = new System.Drawing.Size(210, 134);
            this.lbTienConLai.TabIndex = 0;
            this.lbTienConLai.Text = "1000";
            this.lbTienConLai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.cbTienCuoc1);
            this.groupBox1.Controls.Add(this.rdChan);
            this.groupBox1.Controls.Add(this.rdLe);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(149, 257);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 184);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn chẵn lẻ";
            // 
            // cbTienCuoc1
            // 
            this.cbTienCuoc1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTienCuoc1.FormattingEnabled = true;
            this.cbTienCuoc1.Items.AddRange(new object[] {
            "100",
            "200",
            "300",
            "400",
            "500"});
            this.cbTienCuoc1.Location = new System.Drawing.Point(255, 115);
            this.cbTienCuoc1.Name = "cbTienCuoc1";
            this.cbTienCuoc1.Size = new System.Drawing.Size(121, 39);
            this.cbTienCuoc1.TabIndex = 1;
            // 
            // rdChan
            // 
            this.rdChan.AutoSize = true;
            this.rdChan.Checked = true;
            this.rdChan.Location = new System.Drawing.Point(76, 50);
            this.rdChan.Name = "rdChan";
            this.rdChan.Size = new System.Drawing.Size(103, 36);
            this.rdChan.TabIndex = 0;
            this.rdChan.TabStop = true;
            this.rdChan.Text = "Chẵn";
            this.rdChan.UseVisualStyleBackColor = true;
            // 
            // rdLe
            // 
            this.rdLe.AutoSize = true;
            this.rdLe.Location = new System.Drawing.Point(271, 50);
            this.rdLe.Name = "rdLe";
            this.rdLe.Size = new System.Drawing.Size(67, 36);
            this.rdLe.TabIndex = 0;
            this.rdLe.Text = "Lẻ";
            this.rdLe.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(46, 118);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 32);
            this.label8.TabIndex = 0;
            this.label8.Text = "Số tiền cược:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.cbTienCuoc2);
            this.groupBox2.Controls.Add(this.rd310);
            this.groupBox2.Controls.Add(this.rd1118);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(644, 257);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 184);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chọn tổng số";
            // 
            // cbTienCuoc2
            // 
            this.cbTienCuoc2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTienCuoc2.FormattingEnabled = true;
            this.cbTienCuoc2.Items.AddRange(new object[] {
            "100",
            "200",
            "300",
            "400",
            "500"});
            this.cbTienCuoc2.Location = new System.Drawing.Point(255, 115);
            this.cbTienCuoc2.Name = "cbTienCuoc2";
            this.cbTienCuoc2.Size = new System.Drawing.Size(121, 39);
            this.cbTienCuoc2.TabIndex = 1;
            // 
            // rd310
            // 
            this.rd310.AutoSize = true;
            this.rd310.Checked = true;
            this.rd310.Location = new System.Drawing.Point(60, 50);
            this.rd310.Name = "rd310";
            this.rd310.Size = new System.Drawing.Size(92, 36);
            this.rd310.TabIndex = 0;
            this.rd310.TabStop = true;
            this.rd310.Text = "3-10";
            this.rd310.UseVisualStyleBackColor = true;
            // 
            // rd1118
            // 
            this.rd1118.AutoSize = true;
            this.rd1118.Location = new System.Drawing.Point(255, 50);
            this.rd1118.Name = "rd1118";
            this.rd1118.Size = new System.Drawing.Size(108, 36);
            this.rd1118.TabIndex = 0;
            this.rd1118.Text = "11-18";
            this.rd1118.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(178, 32);
            this.label5.TabIndex = 0;
            this.label5.Text = "Số tiền cược:";
            // 
            // lbSo3
            // 
            this.lbSo3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo3.Location = new System.Drawing.Point(867, 33);
            this.lbSo3.Name = "lbSo3";
            this.lbSo3.Size = new System.Drawing.Size(200, 200);
            this.lbSo3.TabIndex = 0;
            this.lbSo3.Text = "label1";
            this.lbSo3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(637, 482);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 38);
            this.label6.TabIndex = 0;
            this.label6.Text = "Tiền còn lại:";
            // 
            // lbSo1
            // 
            this.lbSo1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbSo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSo1.Location = new System.Drawing.Point(149, 33);
            this.lbSo1.Name = "lbSo1";
            this.lbSo1.Size = new System.Drawing.Size(200, 200);
            this.lbSo1.TabIndex = 0;
            this.lbSo1.Text = "label1";
            this.lbSo1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkGiaoDienHinh
            // 
            this.chkGiaoDienHinh.AutoSize = true;
            this.chkGiaoDienHinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGiaoDienHinh.Location = new System.Drawing.Point(149, 485);
            this.chkGiaoDienHinh.Name = "chkGiaoDienHinh";
            this.chkGiaoDienHinh.Size = new System.Drawing.Size(190, 33);
            this.chkGiaoDienHinh.TabIndex = 2;
            this.chkGiaoDienHinh.Text = "Giao diện hình";
            this.chkGiaoDienHinh.UseVisualStyleBackColor = true;
            this.chkGiaoDienHinh.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // btnQuaySo
            // 
            this.btnQuaySo.Location = new System.Drawing.Point(362, 480);
            this.btnQuaySo.Name = "btnQuaySo";
            this.btnQuaySo.Size = new System.Drawing.Size(210, 134);
            this.btnQuaySo.TabIndex = 3;
            this.btnQuaySo.Text = "Quay số";
            this.btnQuaySo.UseVisualStyleBackColor = true;
            this.btnQuaySo.Click += new System.EventHandler(this.BtnQuaySo_Click);
            // 
            // pctSo1
            // 
            this.pctSo1.Location = new System.Drawing.Point(149, 33);
            this.pctSo1.Name = "pctSo1";
            this.pctSo1.Size = new System.Drawing.Size(200, 200);
            this.pctSo1.TabIndex = 4;
            this.pctSo1.TabStop = false;
            this.pctSo1.Visible = false;
            // 
            // pctSo2
            // 
            this.pctSo2.Location = new System.Drawing.Point(508, 33);
            this.pctSo2.Name = "pctSo2";
            this.pctSo2.Size = new System.Drawing.Size(200, 200);
            this.pctSo2.TabIndex = 4;
            this.pctSo2.TabStop = false;
            this.pctSo2.Visible = false;
            // 
            // pctSo3
            // 
            this.pctSo3.Location = new System.Drawing.Point(867, 33);
            this.pctSo3.Name = "pctSo3";
            this.pctSo3.Size = new System.Drawing.Size(200, 200);
            this.pctSo3.TabIndex = 4;
            this.pctSo3.TabStop = false;
            this.pctSo3.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 38F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1216, 647);
            this.Controls.Add(this.pctSo3);
            this.Controls.Add(this.pctSo2);
            this.Controls.Add(this.pctSo1);
            this.Controls.Add(this.btnQuaySo);
            this.Controls.Add(this.chkGiaoDienHinh);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbTienConLai);
            this.Controls.Add(this.lbSo1);
            this.Controls.Add(this.lbSo3);
            this.Controls.Add(this.lbSo2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(7);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "2151050469_Trần Thanh Hiệp";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctSo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctSo3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbSo2;
        private System.Windows.Forms.Label lbTienConLai;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rd1118;
        private System.Windows.Forms.RadioButton rdChan;
        private System.Windows.Forms.RadioButton rdLe;
        private System.Windows.Forms.RadioButton rd310;
        private System.Windows.Forms.Label lbSo3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbSo1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbTienCuoc1;
        private System.Windows.Forms.ComboBox cbTienCuoc2;
        private System.Windows.Forms.CheckBox chkGiaoDienHinh;
        private System.Windows.Forms.Button btnQuaySo;
        private System.Windows.Forms.PictureBox pctSo1;
        private System.Windows.Forms.PictureBox pctSo2;
        private System.Windows.Forms.PictureBox pctSo3;
    }
}

